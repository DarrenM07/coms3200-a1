"""! @file pubsubserver.py
@author Darren
@ai Inspiration
@ai Wrote Code
@ai Debugging
@ai Testing
@aitool ChatGPT
@aidetails ChatGPT was used to help design, implement, test and debug
command-line parsing, validation, TCP listening, client handling, subscriptions,
filtered publication, rate limiting, file sending, shutdown handling and server
stdin command behaviour for the pubsub server.
"""

import os
import socket
import sys
import time
import threading

from common import filter_matches_message, is_valid_id, is_valid_topic, parse_endpoint
from protocol import make_socket_file, recv_json, send_json


USAGE = "Usage: pubsubserver [--server [server]:port]... [--listenon port] serverid"

clients = {}
subscriptions = {}
rate_limits = {}
last_publish_times = {}
clients_lock = threading.Lock()


def usage_error() -> None:
    print(USAGE, file=sys.stderr, flush=True)
    sys.exit(1)


def parse_args(argv: list[str]) -> dict:
    args = argv[1:]
    peer_args = []
    listen_port = None
    seen_listenon = False

    index = 0
    while index < len(args):
        arg = args[index]

        if arg == "--server":
            if index + 1 >= len(args) or args[index + 1] == "":
                usage_error()
            peer_endpoint = args[index + 1]
            try:
                parse_endpoint(peer_endpoint)
            except ValueError:
                usage_error()
            peer_args.append(peer_endpoint)
            index += 2

        elif arg == "--listenon":
            if seen_listenon:
                usage_error()
            if index + 1 >= len(args) or args[index + 1] == "":
                usage_error()
            listen_port = args[index + 1]
            seen_listenon = True
            index += 2

        elif arg.startswith("-"):
            usage_error()
        else:
            break

    remaining = args[index:]
    if len(remaining) != 1:
        usage_error()

    server_id = remaining[0]
    if server_id == "":
        usage_error()

    return {"peer_args": peer_args, "listen_port": listen_port, "server_id": server_id}


def validate_args(parsed: dict) -> None:
    server_id = parsed["server_id"]
    if not is_valid_id(server_id):
        print(f'pubsubserver: bad server ID "{server_id}"', file=sys.stderr, flush=True)
        sys.exit(2)


def resolve_listen_port(listen_port: str | None) -> int:
    if listen_port is None or listen_port == "0":
        return 0

    try:
        port = int(listen_port)
    except ValueError:
        try:
            return socket.getservbyname(listen_port, "tcp")
        except OSError as exc:
            raise ValueError from exc

    if port < 1024:
        raise PermissionError

    return port


def create_listening_socket(listen_port: str | None) -> socket.socket:
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        port_to_bind = resolve_listen_port(listen_port)
    except (ValueError, PermissionError):
        server_socket.close()
        print(f'pubsubserver: can\'t listen on port "{listen_port}"', file=sys.stderr, flush=True)
        sys.exit(3)

    try:
        server_socket.bind(("", port_to_bind))
        server_socket.listen()
    except OSError:
        server_socket.close()
        shown_port = "0" if listen_port is None else listen_port
        print(f'pubsubserver: can\'t listen on port "{shown_port}"', file=sys.stderr, flush=True)
        sys.exit(3)

    return server_socket


def matching_client_sockets(topic: str, message: str | None = None, file_mode: bool = False) -> list[socket.socket]:
    targets = []
    for subscriber_id, sock in clients.items():
        for subscription in subscriptions.get(subscriber_id, []):
            if subscription["topic"] != topic:
                continue
            filter_data = subscription["filter"]
            if file_mode:
                if filter_data is None:
                    targets.append(sock)
                    break
                continue
            if filter_data is None:
                targets.append(sock)
                break
            if message is not None and filter_matches_message(message, filter_data["operator"], filter_data["value"]):
                targets.append(sock)
                break
    return targets


def check_rate_limit(client_id: str, topic: str) -> bool:
    limit_key = (client_id, topic)
    now = time.time()
    with clients_lock:
        limit_seconds = rate_limits.get(limit_key, 0)
        last_time = last_publish_times.get(limit_key)
        if limit_seconds > 0 and last_time is not None and now - last_time < limit_seconds:
            return False
        if limit_seconds > 0:
            last_publish_times[limit_key] = now
    return True


def handle_connection(client_socket: socket.socket, server_id: str) -> None:
    client_id = None
    client_socket.settimeout(1.0)

    try:
        sock_file = make_socket_file(client_socket)
        message = recv_json(sock_file)

        if message is None or message.get("type") != "hello_client":
            print("pubsubserver: Connection with unknown client aborted", file=sys.stderr, flush=True)
            client_socket.close()
            return

        client_socket.settimeout(None)
        client_id = message.get("clientid")

        with clients_lock:
            if client_id in clients:
                print(f'pubsubserver: Client ID "{client_id}" would be duplicated - aborting connection', flush=True)
                send_json(client_socket, {"type": "error", "code": "duplicate_client_id"})
                client_socket.close()
                return
            clients[client_id] = client_socket
            subscriptions.setdefault(client_id, [])

        send_json(client_socket, {"type": "hello_ack", "serverid": server_id})
        print(f'pubsubserver: Client "{client_id}" has connected', flush=True)

        while True:
            next_message = recv_json(sock_file)
            if next_message is None:
                break

            if next_message.get("type") == "subscribe":
                subscription = {"topic": next_message.get("topic"), "filter": next_message.get("filter")}
                with clients_lock:
                    client_subs = subscriptions.setdefault(client_id, [])
                    if subscription not in client_subs:
                        client_subs.append(subscription)
                continue

            if next_message.get("type") == "unsubscribe":
                topic = next_message.get("topic")
                with clients_lock:
                    client_subs = subscriptions.setdefault(client_id, [])
                    subscriptions[client_id] = [sub for sub in client_subs if sub["topic"] != topic]
                continue

            if next_message.get("type") == "publish":
                topic = next_message.get("topic")
                publish_message = next_message.get("message")

                if not check_rate_limit(client_id, topic):
                    try:
                        send_json(client_socket, {"type": "rate_limit_failed"})
                    except OSError:
                        pass
                    continue

                with clients_lock:
                    targets = matching_client_sockets(topic, publish_message, file_mode=False)

                for target_socket in targets:
                    try:
                        send_json(target_socket, {"type": "deliver_message", "topic": topic, "message": publish_message, "from_client": client_id, "from_server": server_id})
                    except OSError:
                        pass
                continue

            if next_message.get("type") == "send_file":
                topic = next_message.get("topic")
                if not check_rate_limit(client_id, topic):
                    try:
                        send_json(client_socket, {"type": "rate_limit_failed"})
                    except OSError:
                        pass
                    continue

                with clients_lock:
                    targets = matching_client_sockets(topic, None, file_mode=True)

                for target_socket in targets:
                    try:
                        send_json(
                            target_socket,
                            {
                                "type": "deliver_file",
                                "topic": topic,
                                "filename": next_message.get("filename"),
                                "data": next_message.get("data"),
                                "size": next_message.get("size"),
                                "from_client": client_id,
                                "from_server": server_id,
                            },
                        )
                    except OSError:
                        pass
                continue

    except (OSError, ValueError):
        pass
    finally:
        if client_id is not None:
            with clients_lock:
                if clients.get(client_id) is client_socket:
                    del clients[client_id]
                    subscriptions.pop(client_id, None)
                    print(f'pubsubserver: Client "{client_id}" has disconnected', flush=True)
        try:
            client_socket.close()
        except OSError:
            pass


def shutdown_server() -> None:
    with clients_lock:
        client_sockets = list(clients.values())

    for client_socket in client_sockets:
        try:
            send_json(client_socket, {"type": "server_shutdown"})
        except OSError:
            pass
        try:
            client_socket.close()
        except OSError:
            pass

    os._exit(0)


def server_stdin_loop(server_id: str) -> None:
    while True:
        line = sys.stdin.readline()
        if line == "":
            shutdown_server()

        line = line.strip()
        if line == "":
            continue

        args = line.split()
        command = args[0]

        if command == "/quit":
            if len(args) != 1:
                print("pubsubserver: unknown argument(s) - usage: /quit", file=sys.stderr, flush=True)
                continue
            shutdown_server()

        if command == "/listclients":
            if len(args) > 2 or (len(args) == 2 and args[1] != "--all"):
                print("pubsubserver: unknown argument(s) - usage: /listclients [--all]", file=sys.stderr, flush=True)
                continue
            with clients_lock:
                client_names = [f"{server_id}:{client_id}" for client_id in clients.keys()]
            if not client_names:
                print("pubsubserver: No clients connected", flush=True)
            else:
                for name in sorted(client_names):
                    print(name, flush=True)
            continue

        if command == "/listpeers":
            if len(args) > 2 or (len(args) == 2 and args[1] != "--all"):
                print("pubsubserver: unknown argument(s) - usage: /listpeers [--all]", file=sys.stderr, flush=True)
                continue
            print("pubsubserver: No peer servers connected", flush=True)
            continue

        if command == "/limit":
            if len(args) != 4:
                print("pubsubserver: unknown argument(s) - usage: /limit clientid topic N", file=sys.stderr, flush=True)
                continue

            client_id = args[1]
            topic = args[2]
            limit_raw = args[3]

            with clients_lock:
                client_socket = clients.get(client_id)

            if client_socket is None or not is_valid_id(client_id):
                print(f'pubsubserver: Client "{client_id}" is unknown', file=sys.stderr, flush=True)
                continue

            if not is_valid_topic(topic):
                print(f'pubsubserver: Topic "{topic}" is not valid', file=sys.stderr, flush=True)
                continue

            try:
                limit_seconds = int(limit_raw)
            except ValueError:
                print("pubsubserver: Rate limit must be 0 to 3600 seconds inclusive", file=sys.stderr, flush=True)
                continue

            if limit_seconds < 0 or limit_seconds > 3600:
                print("pubsubserver: Rate limit must be 0 to 3600 seconds inclusive", file=sys.stderr, flush=True)
                continue

            with clients_lock:
                rate_limits[(client_id, topic)] = limit_seconds
                last_publish_times.pop((client_id, topic), None)

            try:
                send_json(client_socket, {"type": "rate_limit_notice", "topic": topic, "limit": limit_seconds})
            except OSError:
                pass
            continue

        print("pubsubserver: unknown command", file=sys.stderr, flush=True)


def main() -> None:
    parsed = parse_args(sys.argv)
    validate_args(parsed)

    server_socket = create_listening_socket(parsed["listen_port"])
    actual_port = server_socket.getsockname()[1]
    print(f"pubsubserver: listening on port {actual_port}", file=sys.stderr, flush=True)

    stdin_thread = threading.Thread(target=server_stdin_loop, args=(parsed["server_id"],), daemon=True)
    stdin_thread.start()

    try:
        while True:
            client_socket, _ = server_socket.accept()
            thread = threading.Thread(target=handle_connection, args=(client_socket, parsed["server_id"]), daemon=True)
            thread.start()
    except KeyboardInterrupt:
        server_socket.close()
        sys.exit(0)


if __name__ == "__main__":
    main()
